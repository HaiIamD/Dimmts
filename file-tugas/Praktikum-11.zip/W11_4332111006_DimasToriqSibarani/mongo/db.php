<?php
class DbManager {
	
    //Database configuration
    private $dbhost = '127.0.0.1';
    private $dbport = '27017';
    private $conn;

    function __construct(){
		//connect to MongoDB
        try {
            //Establish databases connection
            $this->conn = new MongoDB\Driver\Manager('mongodb://'.$this->dbhost.':'.$this->dbport);
        }catch (Exception $e) {
            echo $e->getMessage();
            echo nl2br("n");
        }
    }
    function getConnection() {
        return $this->conn;
    }
}
?>